using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using CHEXC.ClassInfo;
using System.Windows.Forms;
namespace CHEXC.GoodMenhod
{
   public class tb_JhGoodsInfoMenthod
    {
        SqlConnection conn = null;
        SqlCommand cmd = null;
        SqlDataReader qlddr = null;
       #region ����
       public int tb_JhGoodsInfoMenthodAdd(tb_JhGoodsInfo tbGood)
       {
           int intFalg = 0;
           try
           {
               
               string str_Add = "insert into tb_JhGoodsInfo values( ";
               str_Add += "'" + tbGood.strGoodsID + "','" + tbGood.strEmpId + "','" + tbGood.strJhCompName + "',";
               str_Add += "'" + tbGood.strGoodsName + "','" + tbGood.strGoodsNum + "',";
               str_Add += "'" + tbGood.strGoodsUnit + "','" + tbGood.deGoodsJhPrice + " ','" + tbGood.deGoodsSellPrice + " ',";
               str_Add += "'" + tbGood.strGoodsRemark + "','"+ tbGood.DaGoodTime + "'," ;
               str_Add += "'"+ tbGood.Falg +"','"+ tbGood.deGoodsAllPrice +"')";
               getSqlConnection getConnection = new getSqlConnection();
               conn = getConnection.GetCon();
               cmd = new SqlCommand(str_Add, conn);
               intFalg = cmd.ExecuteNonQuery();
               conn.Dispose();
               return intFalg;
           }
           catch (Exception ee)
           {
               MessageBox.Show(ee.ToString());
               return intFalg;

           }

       }
       #endregion
       #region �޸�
       public int tb_JhGoodsInfoMenthodUpdate(tb_JhGoodsInfo tbGood)
       {
           int intFalg = 0;
           try
           {
               string str_Add = "update tb_JhGoodsInfo set ";
               str_Add += "EmpId='" + tbGood.strEmpId + "',JhCompName='" + tbGood.strJhCompName + "',";
               str_Add += "GoodsName='" + tbGood.strGoodsName + "',GoodsNum='" + tbGood.strGoodsNum + "',";
               str_Add += "GoodsUnit='" + tbGood.strGoodsUnit + "',GoodsJhPrice=" + tbGood.deGoodsJhPrice + " ,GoodsSellPrice=" + tbGood.deGoodsSellPrice + " ,";
               str_Add += "GoodsAllPrice=" + tbGood.deGoodsAllPrice + ",GoodsRemark='" + tbGood.strGoodsRemark + "',";
               str_Add += "GoodTime='" + tbGood.DaGoodTime + "',Falg='" + tbGood.Falg + "' where GoodsID ='" + tbGood.strGoodsID + "'";
               getSqlConnection getConnection = new getSqlConnection();
               conn = getConnection.GetCon();
               cmd = new SqlCommand(str_Add, conn);
               intFalg = cmd.ExecuteNonQuery();
               conn.Dispose();
               return intFalg;

           }
           catch (Exception ee)
           {
               MessageBox.Show(ee.ToString());
               return intFalg;

           }

       }
            #endregion
       #region ɾ��Ǵ��
       public int tb_JhGoodsInfoMenthodDelete(tb_JhGoodsInfo tbGood)
       {
           int intFalg = 0;
           try
           {
              // string str_Add = "update tb_JhGoodsInfo set ";
               string str_Add = "delete from tb_JhGoodsInfo  ";
              // str_Add += "Falg=" + tbGood.Falg 
               str_Add+= " where GoodsID ='" + tbGood.strGoodsID + "'";
               getSqlConnection getConnection = new getSqlConnection();
               conn = getConnection.GetCon();
               cmd = new SqlCommand(str_Add, conn);
               intFalg = cmd.ExecuteNonQuery();
               conn.Dispose();

               return intFalg;

           }
           catch (Exception ee)
           {
               MessageBox.Show(ee.ToString());
               return intFalg;

           }

       }
  #endregion

       #region ��ѯ
       public void tb_JhGoodsInfoFind(string strObject, int intFalg, Object DataObject)
       {
           int intCount = 0;
           string strSecar = null;

           try
           {
               switch (intFalg)//�ж�����
               {
                   case 1://"��Ʒ���":
                       strSecar = "select * from tb_JhGoodsInfo where GoodsID like  '%" + strObject + "%' and Falg=0";
                       break;
                   case 2://��Ʒ����"

                       strSecar = "select  * from  tb_JhGoodsInfo  where GoodsName like '%" + strObject + "%' and Falg=0";
                       break;
                   case 3://��Ӧ��"
                       strSecar = "select * from tb_JhGoodsInfo where JhCompName like '%" + strObject + "%' and Falg=0";
                       break;
                  case 4://"Ա��ְλ":
                       strSecar = "select * from tb_JhGoodsInfo where EmpId like '%" + strObject + "%' and Falg=0";
                       break;
                   case 5://"Ա��ְλ":
                       strSecar = "select * from tb_JhGoodsInfo where Falg=0";
                       break;
               }
               getSqlConnection getConnection = new getSqlConnection();
               conn = getConnection.GetCon();
               cmd = new SqlCommand(strSecar, conn);
               int ii = 0;
               qlddr = cmd.ExecuteReader();
               while (qlddr.Read())
               {
                   ii++;
               }
               qlddr.Close();


               System.Windows.Forms.DataGridView dv = (DataGridView)DataObject;
              
               if (ii != 0)
               {
                   int i = 0;
                   dv.RowCount = ii;
                   qlddr = cmd.ExecuteReader();
                   while (qlddr.Read())
                   {
                       dv[0, i].Value = qlddr[0].ToString();
                       dv[1, i].Value = qlddr[3].ToString();
                       dv[2, i].Value = qlddr[2].ToString();
                       dv[3, i].Value = qlddr[4].ToString();
                       dv[4, i].Value = qlddr[5].ToString();
                       dv[5, i].Value = qlddr[6].ToString();
                       dv[6, i].Value = qlddr[7].ToString();
                       dv[7, i].Value = qlddr[1].ToString();
                       dv[8, i].Value = qlddr[11].ToString();
                       i++;

                   }
                   qlddr.Close();
               }
               else
               {
                   if (dv.RowCount != 0)
                   {
                       int i = 0;
                       do
                       {
                           dv[0, i].Value = "";
                           dv[1, i].Value = "";
                           dv[2, i].Value = "";
                           dv[3, i].Value = "";
                           dv[4, i].Value = "";
                           dv[5, i].Value = "";
                           dv[6, i].Value = "";
                           dv[7, i].Value = "";
                           dv[8, i].Value = "";
                           i++;
                       } while (i < dv.RowCount);
                   }
               }
             



           }
           catch (Exception ee)
           {
               MessageBox.Show(ee.ToString());

           }

       }
       #endregion

       #region ��ѯ
       public SqlDataReader tb_JhGoodsInfoFind(string strObject, int intFalg)
       {
           int intCount = 0;
           string strSecar = null;

           try
           {
               switch (intFalg)//�ж�����
               {
                   case 1://"��Ų�
                       strSecar = "select * from tb_JhGoodsInfo where GoodsID = '" + strObject + "' and Falg=0";
                       break;
                   case 2://ȫ����ѯ
                       strSecar = "select  * from  tb_JhGoodsInfo  where Falg=0";
                       break;
               }
               getSqlConnection getConnection = new getSqlConnection();
               conn = getConnection.GetCon();
               cmd = new SqlCommand(strSecar, conn);
               qlddr = cmd.ExecuteReader();
               return qlddr;

           }
           catch (Exception ee)
           {
               MessageBox.Show(ee.ToString());

               return qlddr;

           }

       }
       #endregion
       #region //���ɿͻ���� ���磺KH-20071118114255
       public string JhGoodsID()
       {
           int intYear = DateTime.Now.Day;
           int intMonth = DateTime.Now.Month;
           int intDate = DateTime.Now.Year;
           int intHour = DateTime.Now.Hour;
           int intSecond = DateTime.Now.Second;
           int intMinute = DateTime.Now.Minute;
           string strTime = null;
           strTime = intYear.ToString();
           if (intMonth < 10)
           {
               strTime += "0" + intMonth.ToString();
           }
           else
           {
               strTime += intMonth.ToString();
           }
           if (intDate < 10)
           {
               strTime += "0" + intDate.ToString();
           }
           else
           {
               strTime += intDate.ToString();
           }
           if (intHour < 10)
           {
               strTime += "0" + intHour.ToString();
           }
           else
           {
               strTime += intHour.ToString();
           }
           if (intMinute < 10)
           {

               strTime += "0" + intMinute.ToString();
           }
           else
           {
               strTime += intMinute.ToString();
           }
           if (intSecond < 10)
           {

               strTime += "0" + intSecond.ToString();
           }
           else
           {
               strTime += intSecond.ToString();
           }


           return ("SP-" + strTime);



       }// end if 
       #endregion
       #region //�����Ʒ�����Ϣ TrreView�ؼ�
       public void filltProd(object objTreeView, object obimage)
       {
           try
           {
               getSqlConnection getConnection = new getSqlConnection();
               conn = getConnection.GetCon();
               string strSecar = "select * from tb_Company  where Falg=0";
               cmd = new SqlCommand(strSecar, conn);
               qlddr = cmd.ExecuteReader();
  
               if (objTreeView.GetType().ToString() == "System.Windows.Forms.TreeView")
               {
                   System.Windows.Forms.ImageList imlist = (System.Windows.Forms.ImageList)obimage;

                   System.Windows.Forms.TreeView TV = (System.Windows.Forms.TreeView)objTreeView;
                   TV.Nodes.Clear();

                   TV.ImageList = imlist;
                   System.Windows.Forms.TreeNode TN = new System.Windows.Forms.TreeNode("��Ӧ������", 0, 1);
                   while (qlddr.Read())
                   {
                       TN.Nodes.Add("", qlddr[1].ToString(), 0, 1);

                   }
                   TV.Nodes.Add(TN);
                   qlddr.Close();
                   TV.ExpandAll();
               }
           }//
           catch (Exception ee)
           {
               MessageBox.Show(ee.ToString());               
           }

       }// end fi
       #endregion 

       #region //���Ա����Ϣ TrreView�ؼ�
       public void fillEmployee(object objTreeView, object obimage)
       {
           try
           {
               getSqlConnection getConnection = new getSqlConnection();
               conn = getConnection.GetCon();
               string strSecar = "select * from tb_EmpInfo  where EmpFalg=0";
               cmd = new SqlCommand(strSecar, conn);
               qlddr = cmd.ExecuteReader();

               if (objTreeView.GetType().ToString() == "System.Windows.Forms.TreeView")
               {
                   System.Windows.Forms.ImageList imlist = (System.Windows.Forms.ImageList)obimage;

                   System.Windows.Forms.TreeView TV = (System.Windows.Forms.TreeView)objTreeView;
                   TV.Nodes.Clear();

                   TV.ImageList = imlist;
                   System.Windows.Forms.TreeNode TN = new System.Windows.Forms.TreeNode("��Ա����", 0, 1);
                   while (qlddr.Read())
                   {
                       TN.Nodes.Add("", qlddr[1].ToString(), 0, 1);

                   }
                   TV.Nodes.Add(TN);
                   qlddr.Close();
                   TV.ExpandAll();
               }
           }//
           catch (Exception ee)
           {
               MessageBox.Show(ee.ToString());
           }

       }// end fi
       #endregion 
    }
}
